// . if...else Tapşırığı — İmtahan Nəticəsi
// İstifadəçidən bal daxil et (0-100) və nəticəyə görə qiymət çıxart:
// 90+ → A
// 75-89 → B
// 60-74 → C
// 40-59 → D
// 0-39 → F
// Əgər bal düzgün deyilsə → "Yanlış bal daxil edilib"
 
let bal = prompt("balini daxil et");
if(bal<=100 && bal>=90){
console.log("A");
}
else if(bal<=89 && bal>=75){
console.log("B");
}
else if(bal<=74 && bal>=60){
console.log("C");
}
else if(bal<=59 && bal>=40){
console.log("D");
}
else if(bal<=39 && bal>=0){
console.log("F");
}
else{
   console.log("Yanlis bal daxil edilib");
}
